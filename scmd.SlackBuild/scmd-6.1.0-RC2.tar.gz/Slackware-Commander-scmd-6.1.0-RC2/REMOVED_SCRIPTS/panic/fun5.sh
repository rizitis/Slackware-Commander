#!/bin/bash

while true; do
    echo -ne "\r~~>     "
    sleep 0.1
    echo -ne "\r ~~>    "
    sleep 0.1
    echo -ne "\r  ~~>   "
    sleep 0.1
    echo -ne "\r   ~~>  "
    sleep 0.1
    echo -ne "\r    ~~> "
    sleep 0.1
    echo -ne "\r     ~~>"
    sleep 0.1
    echo -ne "\r    <~~ "
    sleep 0.1
    echo -ne "\r   <~~  "
    sleep 0.1
    echo -ne "\r  <~~   "
    sleep 0.1
    echo -ne "\r <~~    "
    sleep 0.1
    echo -ne "\r<~~     "
    sleep 0.1
done

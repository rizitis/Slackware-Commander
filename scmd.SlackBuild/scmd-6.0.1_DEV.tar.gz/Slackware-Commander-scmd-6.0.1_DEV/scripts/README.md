ONLY_SCRIPTS=YES ./SlackwareCommander.SlackBuild will install these scripts.
